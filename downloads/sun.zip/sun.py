import bpy, math, os

TEX    = "C:/Users/Charlie/Downloads/textures/"
FRAMES = 360


# ── Clear scene ───────────────────────────────────────────────────────────────
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

for blk in (bpy.data.meshes, bpy.data.materials,
            bpy.data.images, bpy.data.actions):
    for item in blk:
        try:
            blk.remove(item)
        except:
            pass


def try_load(fp):
    return bpy.data.images.load(fp) if os.path.isfile(fp) else None


# ── Sun material (Eevee emission only) ────────────────────────────────────────
def make_sun_mat():
    mat = bpy.data.materials.new("SunMat")
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    out  = nodes.new("ShaderNodeOutputMaterial")
    emit = nodes.new("ShaderNodeEmission")
    tex  = nodes.new("ShaderNodeTexImage")
    uv   = nodes.new("ShaderNodeTexCoord")

    img = try_load(TEX + "sun.jpg")

    if img:
        tex.image = img
        links.new(uv.outputs["UV"], tex.inputs["Vector"])
        links.new(tex.outputs["Color"], emit.inputs["Color"])
    else:
        emit.inputs["Color"].default_value = (1.0, 0.6, 0.1, 1)

    emit.inputs["Strength"].default_value = 8.0

    links.new(emit.outputs["Emission"], out.inputs["Surface"])
    return mat


# ── Star field (simple Eevee world) ───────────────────────────────────────────
def star_field():
    world = bpy.context.scene.world
    world.use_nodes = True

    nodes = world.node_tree.nodes
    links = world.node_tree.links
    nodes.clear()

    wout  = nodes.new("ShaderNodeOutputWorld")
    bg    = nodes.new("ShaderNodeBackground")
    noise = nodes.new("ShaderNodeTexNoise")
    ramp  = nodes.new("ShaderNodeValToRGB")
    tc    = nodes.new("ShaderNodeTexCoord")

    noise.inputs["Scale"].default_value = 400.0
    noise.inputs["Detail"].default_value = 4.0
    noise.inputs["Roughness"].default_value = 0.6

    cr = ramp.color_ramp
    cr.interpolation = 'CONSTANT'
    cr.elements[0].position = 0.0
    cr.elements[0].color = (0, 0, 0, 1)

    star = cr.elements.new(0.97)
    star.color = (1, 1, 1, 1)

    bg.inputs["Strength"].default_value = 0.8

    links.new(tc.outputs["Generated"], noise.inputs["Vector"])
    links.new(noise.outputs["Fac"], ramp.inputs["Fac"])
    links.new(ramp.outputs["Color"], bg.inputs["Color"])
    links.new(bg.outputs["Background"], wout.inputs["Surface"])


# ── Linear animation helper ───────────────────────────────────────────────────
def linearize(obj):
    ad = obj.animation_data
    if not ad:
        return

    action = getattr(ad, "action", None)
    if not action:
        return

    fcurves = getattr(action, "fcurves", None)
    if not fcurves:
        return

    for fc in fcurves:
        for kp in fc.keyframe_points:
            kp.interpolation = 'LINEAR'


# ═════════════════════════════════════════════════════════════════════════════
# BUILD SCENE
# ═════════════════════════════════════════════════════════════════════════════

# Sun sphere
bpy.ops.mesh.primitive_uv_sphere_add(
    radius=2.2, segments=128, ring_count=64, location=(0, 0, 0))

sun = bpy.context.active_object
sun.name = "Sun"
bpy.ops.object.shade_smooth()
sun.data.materials.append(make_sun_mat())


# ── Light (this actually lights scene in Eevee) ──────────────────────────────
bpy.ops.object.light_add(type='POINT', location=(0, 0, 0))
sl = bpy.context.active_object
sl.name = "SunLight"
sl.data.energy = 50000
sl.data.shadow_soft_size = 2.0


# ── Animation ─────────────────────────────────────────────────────────────────
bpy.context.scene.frame_start = 1
bpy.context.scene.frame_end = FRAMES

sun.rotation_euler[2] = 0
sun.keyframe_insert(data_path="rotation_euler", frame=1)

sun.rotation_euler[2] = math.radians(540)
sun.keyframe_insert(data_path="rotation_euler", frame=FRAMES)

linearize(sun)


# ── Star background ───────────────────────────────────────────────────────────
star_field()


# ── Camera ────────────────────────────────────────────────────────────────────
bpy.ops.object.camera_add(location=(0, -36, 7.5))
cam = bpy.context.active_object
cam.rotation_euler = (math.radians(78), 0, 0)
cam.data.lens = 85
bpy.context.scene.camera = cam


# ── EEVEE SETTINGS (NO COMPOSITOR) ────────────────────────────────────────────
scene = bpy.context.scene
scene.render.engine = 'BLENDER_EEVEE'

# Eevee Bloom (Blender 5.1 correct API)
eevee = scene.eevee

if hasattr(eevee, "use_bloom"):
    eevee.use_bloom = True

if hasattr(eevee, "bloom_intensity"):
    eevee.bloom_intensity = 0.08

if hasattr(eevee, "bloom_radius"):
    eevee.bloom_radius = 6.5

if hasattr(eevee, "bloom_threshold"):
    eevee.bloom_threshold = 0.8

scene.render.resolution_x = 1920
scene.render.resolution_y = 1080

print("Eevee Sun scene ready (no corona, no compositor)!")