import bpy, math, os

TEX = "C:/Users/Charlie/Downloads/textures/"
FRAMES = 360

# ── Clear scene ───────────────────────────────────────────────────────────────
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

for blk in (bpy.data.meshes, bpy.data.materials, bpy.data.images, bpy.data.actions):
    for item in list(blk):
        try:
            blk.remove(item)
        except:
            pass


def try_load(fp):
    return bpy.data.images.load(fp) if os.path.isfile(fp) else None


# ── Pluto material ────────────────────────────────────────────────────────────
def make_pluto_mat():
    mat = bpy.data.materials.new("PlutoMat")
    mat.use_nodes = True

    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    out = nodes.new("ShaderNodeOutputMaterial")
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    tex = nodes.new("ShaderNodeTexImage")
    uv = nodes.new("ShaderNodeTexCoord")

    img = try_load(TEX + "2k_pluto.jpg")

    if img:
        tex.image = img
        links.new(uv.outputs["UV"], tex.inputs["Vector"])
        links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    else:
        bsdf.inputs["Base Color"].default_value = (0.35, 0.30, 0.28, 1)

    bsdf.inputs["Roughness"].default_value = 0.9
    bsdf.inputs["Specular IOR Level"].default_value = 0.1

    links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    return mat


# ── Charon material ───────────────────────────────────────────────────────────
def make_charon_mat():
    mat = bpy.data.materials.new("CharonMat")
    mat.use_nodes = True

    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    out = nodes.new("ShaderNodeOutputMaterial")
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")

    bsdf.inputs["Base Color"].default_value = (0.55, 0.55, 0.58, 1)
    bsdf.inputs["Roughness"].default_value = 0.95

    links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    return mat


# ── Star field ────────────────────────────────────────────────────────────────
def star_field():
    world = bpy.context.scene.world
    world.use_nodes = True

    nodes = world.node_tree.nodes
    links = world.node_tree.links
    nodes.clear()

    wout = nodes.new("ShaderNodeOutputWorld")
    bg = nodes.new("ShaderNodeBackground")
    noise = nodes.new("ShaderNodeTexNoise")
    ramp = nodes.new("ShaderNodeValToRGB")
    tc = nodes.new("ShaderNodeTexCoord")

    noise.inputs["Scale"].default_value = 500.0
    noise.inputs["Detail"].default_value = 2.0

    cr = ramp.color_ramp
    cr.interpolation = 'CONSTANT'
    cr.elements[0].position = 0.0
    cr.elements[0].color = (0, 0, 0, 1)

    star = cr.elements.new(0.975)
    star.color = (1, 1, 1, 1)

    bg.inputs["Strength"].default_value = 0.8

    links.new(tc.outputs["Generated"], noise.inputs["Vector"])
    links.new(noise.outputs["Fac"], ramp.inputs["Fac"])
    links.new(ramp.outputs["Color"], bg.inputs["Color"])
    links.new(bg.outputs["Background"], wout.inputs["Surface"])


# ── SAFE animation helper ─────────────────────────────────────────────────────
def animate(obj, end_rot):
    obj.rotation_euler[2] = 0
    obj.keyframe_insert(data_path="rotation_euler", frame=1)

    obj.rotation_euler[2] = math.radians(end_rot)
    obj.keyframe_insert(data_path="rotation_euler", frame=FRAMES)


# ═════════════════════════════════════════════════════════════════════════════
# PLUTO
# ═════════════════════════════════════════════════════════════════════════════

bpy.ops.mesh.primitive_uv_sphere_add(
    radius=1.4, segments=96, ring_count=48, location=(0, 0, 0))

pluto = bpy.context.active_object
pluto.name = "Pluto"
bpy.ops.object.shade_smooth()
pluto.data.materials.append(make_pluto_mat())


# ═════════════════════════════════════════════════════════════════════════════
# CHARON (orbiting moon)
# ═════════════════════════════════════════════════════════════════════════════

bpy.ops.mesh.primitive_uv_sphere_add(
    radius=0.5, segments=64, ring_count=32, location=(3.0, 0, 0))

charon = bpy.context.active_object
charon.name = "Charon"
bpy.ops.object.shade_smooth()
charon.data.materials.append(make_charon_mat())


# Parent Charon to Pluto so it orbits
charon.parent = pluto


# Orbit animation (Charon around Pluto)
charon.rotation_euler = (0, 0, 0)
animate(charon, 360 * 6)  # orbit speed


# Pluto spin
animate(pluto, 360 * 1.5)


# ── Lights ───────────────────────────────────────────────────────────────────
bpy.ops.object.light_add(type='SUN', location=(6, -4, 3))
sun = bpy.context.active_object
sun.data.energy = 3.0
sun.rotation_euler = (math.radians(30), 0, math.radians(-40))

bpy.ops.object.light_add(type='SUN', location=(-5, 5, 1))
fill = bpy.context.active_object
fill.data.energy = 0.05
fill.rotation_euler = (math.radians(20), 0, math.radians(130))


# ── World ─────────────────────────────────────────────────────────────────────
star_field()


# ── Camera ────────────────────────────────────────────────────────────────────
bpy.ops.object.camera_add(location=(0, -18, 5))
cam = bpy.context.active_object
cam.rotation_euler = (math.radians(75), 0, 0)
cam.data.lens = 90
bpy.context.scene.camera = cam


# ── Render settings (Eevee safe OR Cycles safe) ───────────────────────────────
scene = bpy.context.scene
scene.render.engine = 'CYCLES'

scene.cycles.samples = 16
scene.cycles.use_adaptive_sampling = True
scene.cycles.use_denoising = True

scene.render.resolution_x = 1920
scene.render.resolution_y = 1080
scene.frame_start = 1
scene.frame_end = FRAMES

print("Pluto + Charon scene ready (stable Blender 5.1 version)")