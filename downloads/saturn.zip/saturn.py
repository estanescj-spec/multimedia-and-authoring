import bpy, math, os

TEX = "C:/Users/Charlie/Downloads/textures/"
FRAMES = 360

# ── Clear scene ───────────────────────────────────────────────────────────────
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

for blk in (bpy.data.meshes, bpy.data.materials, bpy.data.images, bpy.data.actions):
    for item in list(blk):
        try:
            blk.remove(item)
        except:
            pass


def try_load(fp):
    return bpy.data.images.load(fp) if os.path.isfile(fp) else None


# ── Saturn material ───────────────────────────────────────────────────────────
def make_saturn_mat():
    mat = bpy.data.materials.new("SaturnMat")
    mat.use_nodes = True

    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    out = nodes.new("ShaderNodeOutputMaterial")
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    tex = nodes.new("ShaderNodeTexImage")
    uv = nodes.new("ShaderNodeTexCoord")

    img = try_load(TEX + "2k_saturn.jpg")

    if img:
        tex.image = img
        links.new(uv.outputs["UV"], tex.inputs["Vector"])
        links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    else:
        bsdf.inputs["Base Color"].default_value = (0.85, 0.78, 0.55, 1)

    bsdf.inputs["Roughness"].default_value = 0.65

    links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    return mat


# ── Ring material (safe alpha) ────────────────────────────────────────────────
def make_ring_mat():
    mat = bpy.data.materials.new("RingMat")
    mat.use_nodes = True
    mat.blend_method = 'BLEND'

    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    out = nodes.new("ShaderNodeOutputMaterial")
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    tex = nodes.new("ShaderNodeTexImage")
    uv = nodes.new("ShaderNodeTexCoord")

    img = try_load(TEX + "2k_saturn_ring_alpha.png")

    if img:
        tex.image = img
        links.new(uv.outputs["UV"], tex.inputs["Vector"])
        links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    else:
        bsdf.inputs["Base Color"].default_value = (0.80, 0.72, 0.55, 1)

    bsdf.inputs["Roughness"].default_value = 0.8

    links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    return mat


# ── Atmosphere (simplified safe version) ─────────────────────────────────────
def make_atmo_volume(radius, color, density):
    bpy.ops.mesh.primitive_uv_sphere_add(
        radius=radius, segments=64, ring_count=32, location=(0, 0, 0))

    obj = bpy.context.active_object
    obj.name = "Atmo_" + str(radius)
    bpy.ops.object.shade_smooth()

    mat = bpy.data.materials.new("AtmoVol")
    mat.use_nodes = True

    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    out = nodes.new("ShaderNodeOutputMaterial")
    vol = nodes.new("ShaderNodeVolumeScatter")

    vol.inputs["Color"].default_value = (*color, 1)
    vol.inputs["Density"].default_value = density

    links.new(vol.outputs["Volume"], out.inputs["Volume"])

    obj.data.materials.append(mat)
    return obj


# ── Star field ────────────────────────────────────────────────────────────────
def star_field():
    world = bpy.context.scene.world
    world.use_nodes = True

    nodes = world.node_tree.nodes
    links = world.node_tree.links
    nodes.clear()

    wout = nodes.new("ShaderNodeOutputWorld")
    bg = nodes.new("ShaderNodeBackground")
    noise = nodes.new("ShaderNodeTexNoise")
    ramp = nodes.new("ShaderNodeValToRGB")
    tc = nodes.new("ShaderNodeTexCoord")

    noise.inputs["Scale"].default_value = 400.0
    noise.inputs["Detail"].default_value = 4.0
    noise.inputs["Roughness"].default_value = 0.6

    cr = ramp.color_ramp
    cr.interpolation = 'CONSTANT'

    cr.elements[0].position = 0.0
    cr.elements[0].color = (0, 0, 0, 1)

    star = cr.elements.new(0.97)
    star.color = (1, 1, 1, 1)

    bg.inputs["Strength"].default_value = 0.8

    links.new(tc.outputs["Generated"], noise.inputs["Vector"])
    links.new(noise.outputs["Fac"], ramp.inputs["Fac"])
    links.new(ramp.outputs["Color"], bg.inputs["Color"])
    links.new(bg.outputs["Background"], wout.inputs["Surface"])


# ── SAFE animation (NO fcurve access) ─────────────────────────────────────────
def add_rotation(obj, speed):
    obj.rotation_euler[2] = 0
    obj.keyframe_insert(data_path="rotation_euler", frame=1)

    obj.rotation_euler[2] = math.radians(360 * speed)
    obj.keyframe_insert(data_path="rotation_euler", frame=FRAMES)


# ═════════════════════════════════════════════════════════════════════════════
# BUILD SATURN
# ═════════════════════════════════════════════════════════════════════════════

bpy.ops.mesh.primitive_uv_sphere_add(
    radius=2.2, segments=128, ring_count=64, location=(0, 0, 0))

saturn = bpy.context.active_object
saturn.name = "Saturn"

saturn.scale = (1.0, 1.0, 0.90)
bpy.ops.object.transform_apply(scale=True)

saturn.rotation_euler[0] = math.radians(26.7)
bpy.ops.object.shade_smooth()

saturn.data.materials.append(make_saturn_mat())


# ── Atmosphere ────────────────────────────────────────────────────────────────
make_atmo_volume(2.32, (0.90, 0.82, 0.58), 0.015)


# ── Rings (fixed: no modifier crash) ─────────────────────────────────────────
bpy.ops.mesh.primitive_circle_add(
    radius=5.5, vertices=128, fill_type='NGON', location=(0, 0, 0))

rings = bpy.context.active_object
rings.name = "SaturnRings"
rings.rotation_euler[0] = math.radians(26.7)
bpy.ops.object.shade_smooth()

rings.data.materials.append(make_ring_mat())


# ── Lights ───────────────────────────────────────────────────────────────────
bpy.ops.object.light_add(type='SUN', location=(6, -4, 3))
sun = bpy.context.active_object
sun.data.energy = 2.5
sun.rotation_euler = (math.radians(28), 0, math.radians(-38))

bpy.ops.object.light_add(type='SUN', location=(-5, 5, 1))
fill = bpy.context.active_object
fill.data.energy = 0.06
fill.rotation_euler = (math.radians(20), 0, math.radians(130))


# ── Animation ────────────────────────────────────────────────────────────────
# ── Animation ────────────────────────────────────────────────────────────────
bpy.context.scene.frame_start = 1
bpy.context.scene.frame_end = FRAMES

# Saturn rotates fast
add_rotation(saturn, 20)

# Rings rotate slower
add_rotation(rings, 5)

star_field()


# ── Camera ────────────────────────────────────────────────────────────────────
bpy.ops.object.camera_add(location=(0, -36, 10))
cam = bpy.context.active_object
cam.rotation_euler = (math.radians(75), 0, 0)
cam.data.lens = 85
bpy.context.scene.camera = cam


# ── Render ────────────────────────────────────────────────────────────────────
scene = bpy.context.scene
scene.render.engine = 'CYCLES'

scene.cycles.samples = 32
scene.cycles.use_adaptive_sampling = True
scene.cycles.use_denoising = True

scene.render.resolution_x = 1920
scene.render.resolution_y = 1080

print("Saturn scene ready (stable Blender 5.1 version)")
